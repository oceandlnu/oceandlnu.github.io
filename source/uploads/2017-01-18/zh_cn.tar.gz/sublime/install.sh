#!/bin/bash 
a=`getconf LONG_BIT` 
 cp -f $a/libsublime-imfix.so /opt/sublime_text/
 cp -f subl /usr/bin/subl
 cp -f sublime_text.desktop /usr/share/applications/ 
echo "处理完成!"


 
